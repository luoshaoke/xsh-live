<?php

$config = array(
	'db_host' => 'localhost',
	'db_name' => 'test',
	'db_user' => 'root',
	'db_pwd' => 'A2099420',
	'db_charset' => 'utf8',
	'ralateUid' => '2633531031',
	'host' => 'http://113.16.76.35/live/',
	'topic' => '相思湖网站图文直播'
);

?>
