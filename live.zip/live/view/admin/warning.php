<?php
global $warning;
echo <<< EOT
<div class="info warning">
	<p>{$warning}</p>
</div>
EOT;
?>
