<h2 class="target">登录</h2>
<form class="login" action="?intent=admin&amp;target=login" method="POST">
	<fieldset>
		<legend>登录</legend>
		<p class="name">
			<label for="name">管理员：</label>
			<br />
			<input id="name" class="textedit" name="name" type="text" />
		</p>
		<p class="password">
			<label for="password">密码：</label>
			<br />
			<input id="password" class="textedit" name="password" type="password" />
		</p>
		<div class="submit">
			<button id="submit" class="button" type="submit">登录</button>
		</div>
	</fieldset>
</form>
