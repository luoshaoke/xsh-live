<?php
global $message;
echo <<< EOT
<div class="info message">
	<p>{$message}</p>
</div>
EOT;
?>
