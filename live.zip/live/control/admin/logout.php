<?php

session_destroy();
header('location:?intent=admin&target=login');

?>
