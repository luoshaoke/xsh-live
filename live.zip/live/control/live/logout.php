<?php

session_destroy();
header('location:?intent=live&target=login');

?>
